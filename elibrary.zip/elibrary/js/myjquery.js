
$(document).ready(function(){
$('#navmenu2').hover(function(){
$(this).find('.sub1#link1').stop().fadeToggle(400);

});

$('#navmenu3').hover(function(){
$(this).find('.sub1#link1').stop().fadeToggle(400);

});

$('#navmenu4').hover(function(){
$(this).find('.sub1#link2').stop().fadeToggle(400);

});

$('#subnavmenu4').hover(function(){
$(this).find('.sub2#sublink1').stop().fadeToggle(400);

});
});
