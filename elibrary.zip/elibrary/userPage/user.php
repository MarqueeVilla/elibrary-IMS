<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<?php
 if(!isset($_SESSION)){
    session_start();
}
require_once("../databaseConnect.php") ?>

<?php
$firstName = $_SESSION['firstName'];
$lastName = $_SESSION['lastName'];
$userName = $_SESSION['userName'];
$location = $_SESSION['location'];
$userType = $_SESSION['userType'];
$profession=$_SESSION['profession'];
$phoneNumber=$_SESSION['phoneNumber'];
$userType=ucfirst($userType);

if($userType=="Admin")
{
header("location:../adminPage/adminLogin.php");
}
if($userType=="Sysadmin")
{
header("location:../sysAdminPage/sysadmin.php");
}

?>

<html xmlns="http://www.w3.org/1999/xhtml" xml: lang="en" lang="en">

<head><title>ELIMS::E-Library Information Management System</title>
<link rel="stylesheet" type="text/css" href="../css/divs.css">
<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="../css/bootstrap-responsive.css">
<script type="text/javascript" src="../js/jquery.js"></script>
<script type="text/javascript" src="../js/myjquery.js"></script>
<link rel="shortcut icon" href="../images/icon.ico" />

</head>

<body>

<div class="body1">

<div class="menubox">


<h5 align="center">Welcome, you are currently logged in as <?php echo $firstName; ?>!!</h4>

<h5 class="afterLogin" align="center">User Type:<?php echo $userType;?></h5>

<a href="../logOut.php" class="logout">Logout</a>
</div>
<div class="banner">
<h1>ELIMS<br></h1>

<h2>E-Library Information Management System</h2>
</div>



<?php
/*Adds the locations in the sub menu*/


$edr=mysql_query("SELECT * FROM districtdr WHERE DR='EDR' ORDER BY district ASC") or die(mysql_error());
$cdr=mysql_query("SELECT * FROM districtdr WHERE DR='CDR' ORDER BY district ASC") or die(mysql_error());
$wdr=mysql_query("SELECT * FROM districtdr WHERE DR='WDR' ORDER BY district ASC") or die(mysql_error());
$mwdr=mysql_query("SELECT * FROM districtdr WHERE DR='MWDR' ORDER BY district ASC") or die(mysql_error());
$fwdr=mysql_query("SELECT * FROM districtdr WHERE DR='FWDR' ORDER BY district ASC") or die(mysql_error());


?>
<ul id="menu">
    <li><a href="user.php">Home</a></li>
    <li>
        <a href="user_site.php">Site</a>
        <ul>
            <li><a href="#">Eastern DR</a>
			<ul>
			<?php
			
			while($row = mysql_fetch_array($edr)) {
			$district1=$row['district'];
			$siteEDR=mysql_query("SELECT * FROM site_maps WHERE district='$district1'") or die(mysql_error());
			while($rowEDR = mysql_fetch_array($siteEDR)) {
			
					echo '<li><a href="user_site.php?action='.$rowEDR['name'].'">'.$rowEDR['name'].'</a></li>';
							
							}
							
						}
			?>
					
			</ul>
			</li>
            <li><a href="#">Central DR</a>
			<ul>
			
			<?php
			
			while($row = mysql_fetch_array($cdr)) {
			$district1=$row['district'];
			$siteCDR=mysql_query("SELECT * FROM site_maps WHERE district='$district1'") or die(mysql_error());
			while($rowCDR = mysql_fetch_array($siteCDR)) {
					$siteName1=$rowCDR['name'];
					echo '<li><a href="user_site.php?action='.$siteName1.'">'.$siteName1.'</a></li>';
							
							
							}
							
						}
			?>
			</ul>			
			</li>
            <li><a href="#">Western DR</a>
			
			<ul>
			
			<?php
			
			while($row = mysql_fetch_array($wdr)) {
			$district1=$row['district'];
			$siteWDR=mysql_query("SELECT * FROM site_maps WHERE district='$district1'") or die(mysql_error());
			while($rowWDR = mysql_fetch_array($siteWDR)) {
					$siteName1=$rowWDR['name'];
					echo '<li><a href="user_site.php?action='.$siteName1.'">'.$siteName1.'</a></li>';
							
							
							}
							
						}
			?>
			</ul>			
			
			</li>
            <li><a href="#">Mid Western DR</a>
			
			
			<ul>
			
			<?php
			
			while($row = mysql_fetch_array($mwdr)) {
			$district1=$row['district'];
			$siteMWDR=mysql_query("SELECT * FROM site_maps WHERE district='$district1'") or die(mysql_error());
			while($rowMWDR = mysql_fetch_array($siteMWDR)) {
					$siteName1=$rowMWDR['name'];
					echo '<li><a href="user_site.php?action='.$siteName1.'">'.$siteName1.'</a></li>';
							
							
							}
							
						}
			?>
			</ul>			
			
			</li>
			<li><a href="#">Far Western DR</a>
			
			
			<ul>
			
			<?php
			
			while($row = mysql_fetch_array($fwdr)) {
			$district1=$row['district'];
			$siteFWDR=mysql_query("SELECT * FROM site_maps WHERE district='$district1'") or die(mysql_error());
			while($rowFWDR = mysql_fetch_array($siteFWDR)) {
					$siteName1=$rowFWDR['name'];
					echo '<li><a href="user_site.php?action='.$siteName1.'">'.$siteName1.'</a></li>';
							
							
							}
							
						}
			?>
			</ul>			
			
			</li>
	
		
			
			
        </ul>
    </li>
    <li><a href="#">Work</a>
	    <ul>
            <li><a href="#">Community</a></li>
            <li><a href="#">School Development</a></li>
            <li><a href="#">Computer Destributions</a></li>
            <li><a href="#">LTSP</a></li>
        </ul>
	</li>
    <li><a href="#">About</a></li>
    <li><a href="#">Contact</a></li>
	<li><a href="complain.php">Complain</a></li>
	
	
</ul>

<?php			/*End of the drop down menu*/

 ?>

 

	
	
	<div class="row">
					<div class="col-md-8 col-sm-6">
						<div class="panel panel-primary">
						
							<div class="panel-heading">
							
							
								
									<font color ="black"size='2' face='Verdana, Arial, Helvetica, sans-serif'>
									&emsp;&emsp;	 ANNOUNCEMENT:
									</font>
							</div>  
                        
							<div class="panel-body">
              <BR>
			  
					
					
					
		<?php
		$connection = mysql_connect("localhost", "root", "");
		$db = mysql_select_db("db_elims", $connection);
		

		$select= "SELECT * from admin_news WHERE id =(SELECT MAX(ID) FROM admin_news)" ;
		$result = @mysql_query ($select); 
		while($row = mysql_fetch_array($result))
		{
		
		echo "&emsp;&emsp;&emsp;";
		echo"<td>
		
		<b> ADMINISTRATOR:</b></td>";
		echo "<br>";echo "<br>";
		echo "&emsp;&emsp;&emsp;";echo "&emsp;&emsp;&emsp;";
echo "<b>";echo "&emsp;&emsp;&emsp;";
		echo $row['news'];
		echo "<br>";
		
		
		echo "</b>";echo "&emsp;&emsp;&emsp;";echo "&emsp;&emsp;&emsp;";
		
		echo "&emsp;&emsp;&emsp;";
		echo "<small>" ;echo "<small>" ;
		echo $row['date'] ;
		echo " at ";
		echo $row['time'];	
		echo "</small>";echo "</small>";
			echo "<hr>";
			
		
		echo "</tr>";
	
		
		
}

?>

	<center>	<h5><b><a href ='admin_old_news.php' target='blank' style='text-decoration: none'><font color='red' title ='View old post'> Recently post announcement</b> <br> <br></a></font></h5>
	</center>

</div>

		<?php
		error_reporting(0);
		$connection = mysql_connect("localhost", "root", "");
		$db = mysql_select_db("db_elims", $connection);	
			

		if(isset($_POST['delete']))
		{
		$delete="Delete from admin_news order by id desc Limit 1";
		$result = @mysql_query ($delete);
		echo "<script>window.location.assign('admin_home.php')</script>";
		}
		?>		
		</div></div></div></div></div> <br>
 
 
 
 
 


<div class="contentBox"><?php if(isset($_SESSION['complain']))echo $_SESSION['complain']?></div>
<?php
$_SESSION['complain']='';
?>
</div>
<div class="footer">HeNN(Help Nepal Network)<br>
GPO Box No.: 1794, Kathmandu | Ph.: 977 1 5003060 | Fax: 977 1 5003131<br>
Copyright &#169 2014  Dhulikhel. All rights reserved<br>
</div>

</body>